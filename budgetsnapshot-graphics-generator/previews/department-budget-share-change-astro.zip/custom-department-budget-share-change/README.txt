BGA custom graphic — Astro export

Graphic ID: custom-department-budget-share-change
Article marker: [budget-graphic id="custom-department-budget-share-change"]

Unzip and open preview.html to review the frozen chart and interactive tooltips offline.

OPTION 1: AN ASTRO PAGE OR COMPONENT
Copy this entire custom-department-budget-share-change folder into src/graphics/ in your Astro project.
Import the included component in an .astro page's frontmatter:

import CustomGraphic from '../graphics/custom-department-budget-share-change/custom-department-budget-share-change.astro';

Adjust the relative import path to your page, then insert <CustomGraphic /> in its markup.
The component imports the HTML as raw text; no client framework or data fetch is needed.

OPTION 2: THIS PROJECT'S WORDPRESS SNAPSHOT MARKERS
If the article has no graphics folder yet:
1. Copy this entire folder to bga-budget-snapshots-astro/src/graphics/custom-department-budget-share-change/.
2. Set graphicsFolder: 'custom-department-budget-share-change' on that article in src/config/snapshots.js.
3. Put [budget-graphic id="custom-department-budget-share-change"] in its own WordPress Paragraph block.
4. Rebuild the Astro project.

If the article already uses a graphicsFolder:
1. Copy custom-department-budget-share-change.html, custom-department-budget-share-change.svg, custom-department-budget-share-change.csv, custom-department-budget-share-change.json and custom-department-budget-share-change.astro into that existing folder.
2. Append the single entry in this manifest's graphics array to the existing manifest's graphics array. Keep all existing entries and top-level metadata.
3. Keep the existing budget-graphics.css and budget-tooltips.js files. Do not overwrite the existing manifest.
4. Add [budget-graphic id="custom-department-budget-share-change"] as its own WordPress Paragraph block and rebuild.

The custom fragment contains its own scoped tooltip initialization, so it works alongside the snapshot runtime. Each exported graphic ID must be unique, and each marker appears once per article. Use a different custom graphic ID when exporting another chart.

The SVG and HTML retain your settings, titles, rotated labels, source notes, and current data. The JSON is an editable generator project. CSV retains raw supplied values. No View data panel or logo is added. Fonts use installed brand fonts or system fallbacks. The ZIP needs no external libraries or network requests. Site policy must allow inline scripts for custom tooltips.
