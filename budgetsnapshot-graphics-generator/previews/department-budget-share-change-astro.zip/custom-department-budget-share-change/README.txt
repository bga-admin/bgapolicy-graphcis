BGA custom graphic — Astro export

Graphic ID: custom-department-budget-share-change
Article marker: [budget-graphic id="custom-department-budget-share-change"]

Unzip and open preview.html to review the frozen chart and interactive tooltips offline.

OPTION 1: AN ASTRO PAGE OR COMPONENT
Copy this entire custom-department-budget-share-change folder into src/graphics/ in your Astro project.
Import the included component in an .astro page's frontmatter:

import CustomGraphic from '../graphics/custom-department-budget-share-change/custom-department-budget-share-change.astro';

Adjust the relative import path to your page, then insert <CustomGraphic /> in its markup.
The component imports the HTML as raw text; no client framework or data fetch is needed.

OPTION 2: THIS PROJECT'S WORDPRESS SNAPSHOT MARKERS
Easiest option (works for any story):
1. Copy this entire custom-department-budget-share-change folder anywhere under bga-budget-snapshots-astro/src/graphics/.
   For example: src/graphics/2027/chicago-budget-analysis/custom-department-budget-share-change/manifest.json.
   src/graphics/custom/custom-department-budget-share-change/ also still works.
2. Put [budget-graphic id="custom-department-budget-share-change"] in its own WordPress Paragraph block.
3. Rebuild the Astro project. No snapshots.js or manifest edits are needed.

To keep a graphic with a particular story instead:
1. Copy this entire custom-department-budget-share-change folder INSIDE the story's existing graphicsFolder.
   For example: src/graphics/2027/ipra-copa/2026-recommendation/custom-department-budget-share-change/manifest.json.
2. Add [budget-graphic id="custom-department-budget-share-change"] as its own WordPress Paragraph block and rebuild.

Keep each export's folder name matching its graphic ID. Year and project grouping names are unrestricted. Astro finds ID-named folders recursively; duplicate matches cause a clear error unless a story graphicsFolder selects the intended bundle or direct child. Retain the whole folder and its manifest; do not flatten folders or merge manifests. Keep the existing budget-graphics.css and budget-tooltips.js in the story's parent folder unchanged. Existing flat snapshot charts continue to work and take precedence when an ID is already in the parent manifest.

These automatic folder lookups require the updated graphics.js importer in this repository. Other Astro projects can use OPTION 1 above.

The custom fragment contains its own scoped tooltip initialization, so it works alongside the snapshot runtime. Each exported graphic ID must be unique, and each marker appears once per article. Use a different custom graphic ID when exporting another chart.

The SVG and HTML retain your settings, titles, rotated labels, source notes, and current data. The JSON is an editable generator project. CSV retains raw supplied values. No View data panel or logo is added. Fonts use installed brand fonts or system fallbacks. The ZIP needs no external libraries or network requests. Site policy must allow inline scripts for custom tooltips.
